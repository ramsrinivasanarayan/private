// Mock file for CSS imports
module.exports = {};
