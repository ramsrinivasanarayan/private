// Mock file for image imports
module.exports = 'test-file-stub';
